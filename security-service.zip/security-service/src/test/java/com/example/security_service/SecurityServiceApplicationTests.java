package com.example.security_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SecurityServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
